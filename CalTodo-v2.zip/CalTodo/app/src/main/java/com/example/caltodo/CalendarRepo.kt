package com.example.caltodo

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset

/** One occurrence of an event read from the phone's calendar. */
data class CalEvent(
    val id: Long,
    val title: String,
    val start: Long,
    val end: Long,
    val allDay: Boolean,
) {
    /** All-day events are stored at UTC midnight, timed events in real time. */
    fun localDate(): LocalDate {
        val zone = if (allDay) ZoneOffset.UTC else ZoneId.systemDefault()
        return Instant.ofEpochMilli(start).atZone(zone).toLocalDate()
    }
}

/**
 * Talks to Android's Calendar Provider, which exposes every calendar on the phone
 * (Google Calendar included), so no API keys or sign-in are needed here.
 */
class CalendarRepo(private val context: Context) {

    fun hasPermission(): Boolean =
        listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR).all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

    fun eventsForMonth(month: YearMonth): List<CalEvent> {
        if (!hasPermission()) return emptyList()
        val zone = ZoneId.systemDefault()
        // One day of padding on both sides so all-day events at the edges are not missed.
        val begin = month.atDay(1).minusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val end = month.plusMonths(1).atDay(1).plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, begin)
            ContentUris.appendId(it, end)
        }.build()

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
        )

        val result = mutableListOf<CalEvent>()
        try {
            context.contentResolver.query(
                uri, projection, null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    result += CalEvent(
                        id = c.getLong(0),
                        title = c.getString(1)?.takeIf { it.isNotBlank() } ?: "(No title)",
                        start = c.getLong(2),
                        end = c.getLong(3),
                        allDay = c.getInt(4) == 1,
                    )
                }
            }
        } catch (e: SecurityException) {
            // Permission was revoked while the app was open.
        }
        return result
    }

    /** Writes the task as an all-day event and returns the new event id, or null on failure. */
    fun addTaskAsEvent(title: String, date: LocalDate): Long? {
        if (!hasPermission()) return null
        val calendarId = writableCalendarId() ?: return null
        val startUtc = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, startUtc)
            put(CalendarContract.Events.DTEND, startUtc + DAY_MS)
            put(CalendarContract.Events.ALL_DAY, 1)
            put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
        }
        return try {
            context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                ?.lastPathSegment?.toLongOrNull()
        } catch (e: Exception) {
            null
        }
    }

    fun deleteEvent(eventId: Long) {
        if (!hasPermission()) return
        try {
            context.contentResolver.delete(
                ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null
            )
        } catch (e: Exception) {
            // Event may already be gone; nothing to do.
        }
    }

    /** Picks a visible calendar we are allowed to write to, preferring a Google account. */
    private fun writableCalendarId(): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.ACCOUNT_TYPE,
        )
        val selection =
            "${CalendarContract.Calendars.VISIBLE} = 1 AND " +
                "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= " +
                "${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"

        val found = mutableListOf<Pair<Long, String?>>()
        try {
            context.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI, projection, selection, null, null
            )?.use { c ->
                while (c.moveToNext()) found += c.getLong(0) to c.getString(1)
            }
        } catch (e: SecurityException) {
            return null
        }
        return (found.firstOrNull { it.second == "com.google" } ?: found.firstOrNull())?.first
    }

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
