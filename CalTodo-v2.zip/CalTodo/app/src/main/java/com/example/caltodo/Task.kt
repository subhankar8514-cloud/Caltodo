package com.example.caltodo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** A to-do item. [eventId] is set when the task was also written to the phone calendar. */
data class Task(
    val id: Long,
    val title: String,
    val date: LocalDate,
    val done: Boolean = false,
    val eventId: Long? = null,
)

/** Keeps tasks on the device as a small JSON blob in SharedPreferences. */
class TaskStore(context: Context) {
    private val prefs = context.getSharedPreferences("caltodo", Context.MODE_PRIVATE)

    fun load(): List<Task> {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Task(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    date = LocalDate.parse(o.getString("date")),
                    done = o.optBoolean("done", false),
                    eventId = if (o.isNull("eventId")) null else o.getLong("eventId"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach { t ->
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("title", t.title)
                    .put("date", t.date.toString())
                    .put("done", t.done)
                    .put("eventId", t.eventId ?: JSONObject.NULL)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "tasks"
    }
}
