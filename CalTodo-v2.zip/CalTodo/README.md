# CalTodo

A small Android app that combines a month calendar with a to-do list.

## What it does (v1)

- Month calendar (weeks start on Sunday). Tap a day to see its tasks and calendar events.
- Dots under a day: filled with the primary colour = has tasks, tertiary colour = has calendar events.
- Add tasks to the selected day with the **+** button. Tick to complete, ✕ to delete.
- **Calendar sync** through Android's Calendar Provider:
  - Shows events from every calendar on the phone (Google Calendar included) next to your tasks.
  - When adding a task you can tick "Also add to my calendar". It is written as an all-day event,
    so it shows up in Google Calendar too. Deleting the task removes that event.
- Tasks are stored on the device (SharedPreferences, JSON).

## Run it

1. Install Android Studio (Koala 2024.1 or newer).
2. `File > Open` and pick this `CalTodo` folder. Let Gradle sync finish (needs internet the first time).
3. Plug in an Android phone with USB debugging on, or start an emulator, then press Run.
4. Tap **Connect** in the app and allow calendar access.

## Known limits of v1

- Multi-day calendar events show only on their first day.
- Task completion is stored in the app only; the calendar event does not get a "done" state.
- Tasks live on this phone only (no cloud backup or multi-device sync).
- Changes made to a synced event in another calendar app do not update the task title.

## Project layout

- `app/src/main/java/com/example/caltodo/MainActivity.kt` - all Compose UI
- `TodoViewModel.kt` - app state
- `CalendarRepo.kt` - reads and writes the phone calendar
- `Task.kt` - task model and local storage
