package com.example.caltodo

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TodoApp()
                }
            }
        }
    }
}

@Composable
fun TodoApp(vm: TodoViewModel = viewModel()) {
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.refreshEvents() }

    // Pick up calendar changes made in other apps whenever we come back to the screen.
    LifecycleResumeEffect(Unit) {
        vm.refreshEvents()
        onPauseOrDispose { }
    }

    var showAdd by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<CalEvent?>(null) }

    val context = LocalContext.current
    LaunchedEffect(vm.notice) {
        vm.notice?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            vm.clearNotice()
        }
    }

    val today = LocalDate.now()
    val tasksByDate = vm.tasks.groupBy { it.date }
    val events = vm.visibleEvents()
    val eventsByDate = events.groupBy { it.localDate() }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Text("+", style = MaterialTheme.typography.headlineMedium)
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            MonthHeader(
                month = vm.month,
                onPrev = { vm.changeMonth(-1) },
                onNext = { vm.changeMonth(1) },
                onTitleClick = { vm.goToday() },
            )
            WeekdayRow()
            MonthGrid(
                month = vm.month,
                selected = vm.selected,
                today = today,
                hasTask = { tasksByDate.containsKey(it) },
                hasEvent = { eventsByDate.containsKey(it) },
                onSelect = { vm.selectDate(it) },
            )
            Spacer(Modifier.height(12.dp))
            DayDetails(
                date = vm.selected,
                tasks = tasksByDate[vm.selected].orEmpty(),
                events = eventsByDate[vm.selected].orEmpty(),
                calendarConnected = vm.calendarConnected,
                onConnect = {
                    permissionLauncher.launch(
                        arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                    )
                },
                onToggle = { vm.toggle(it.id) },
                onDelete = { vm.delete(it) },
                onDeleteEvent = { pendingDelete = it },
                modifier = Modifier.weight(1f),
            )
        }
    }

    pendingDelete?.let { event ->
        DeleteEventDialog(
            event = event,
            onDismiss = { pendingDelete = null },
            onDelete = { wholeSeries -> vm.deleteCalendarEvent(event, wholeSeries) },
        )
    }

    if (showAdd) {
        AddTaskDialog(
            date = vm.selected,
            canSync = vm.calendarConnected,
            onDismiss = { showAdd = false },
            onAdd = { title, sync -> vm.addTask(title, sync) },
        )
    }
}

@Composable
private fun MonthHeader(
    month: YearMonth,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onTitleClick: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onPrev) { Text("‹", style = MaterialTheme.typography.headlineSmall) }
        Text(
            text = month.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onTitleClick),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        TextButton(onClick = onNext) { Text("›", style = MaterialTheme.typography.headlineSmall) }
    }
}

@Composable
private fun WeekdayRow() {
    Row(Modifier.fillMaxWidth()) {
        listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
            Text(
                text = d,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    selected: LocalDate,
    today: LocalDate,
    hasTask: (LocalDate) -> Boolean,
    hasEvent: (LocalDate) -> Boolean,
    onSelect: (LocalDate) -> Unit,
) {
    // Weeks start on Sunday: Sunday has dayOfWeek.value 7, so % 7 maps it to column 0.
    val blanks = month.atDay(1).dayOfWeek.value % 7
    val days = month.lengthOfMonth()
    val rows = (blanks + days + 6) / 7

    Column {
        repeat(rows) { r ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { c ->
                    val dayNum = r * 7 + c - blanks + 1
                    Box(
                        Modifier
                            .weight(1f)
                            .height(50.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (dayNum in 1..days) {
                            val date = month.atDay(dayNum)
                            DayCell(
                                day = dayNum,
                                isSelected = date == selected,
                                isToday = date == today,
                                hasTask = hasTask(date),
                                hasEvent = hasEvent(date),
                                onClick = { onSelect(date) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    day: Int,
    isSelected: Boolean,
    isToday: Boolean,
    hasTask: Boolean,
    hasEvent: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val fg = if (isSelected) colors.onPrimary else colors.onSurface

    Column(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (isSelected) colors.primary else Color.Transparent)
            .then(
                if (isToday && !isSelected) Modifier.border(1.dp, colors.primary, CircleShape)
                else Modifier
            )
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "$day",
            color = fg,
            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
        )
        Row(
            modifier = Modifier.height(6.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (hasTask) Dot(if (isSelected) colors.onPrimary else colors.primary)
            if (hasEvent) Dot(if (isSelected) colors.onPrimary else colors.tertiary)
        }
    }
}

@Composable
private fun Dot(color: Color) {
    Box(
        Modifier
            .size(5.dp)
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
private fun DayDetails(
    date: LocalDate,
    tasks: List<Task>,
    events: List<CalEvent>,
    calendarConnected: Boolean,
    onConnect: () -> Unit,
    onToggle: (Task) -> Unit,
    onDelete: (Task) -> Unit,
    onDeleteEvent: (CalEvent) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier) {
        Text(
            text = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            if (!calendarConnected) {
                item(key = "banner") { SyncBanner(onConnect) }
            }
            if (tasks.isEmpty() && events.isEmpty()) {
                item(key = "empty") {
                    Text(
                        text = "Nothing planned. Tap + to add a task.",
                        modifier = Modifier.padding(vertical = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(tasks, key = { "t${it.id}" }) { task ->
                TaskRow(task, onToggle = { onToggle(task) }, onDelete = { onDelete(task) })
            }
            items(events, key = { "e${it.id}-${it.start}" }) { event ->
                EventRow(event, onDelete = { onDeleteEvent(event) })
            }
        }
    }
}

@Composable
private fun SyncBanner(onConnect: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Connect your calendar to see events and sync tasks.",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = onConnect) { Text("Connect") }
        }
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = task.done, onCheckedChange = { onToggle() })
        Text(
            text = task.title,
            modifier = Modifier.weight(1f),
            textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
            color = if (task.done) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.onSurface,
        )
        if (task.eventId != null) {
            Text(
                text = "Synced",
                modifier = Modifier.padding(horizontal = 8.dp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary,
            )
        }
        TextButton(onClick = onDelete) { Text("✕") }
    }
}

@Composable
private fun EventRow(event: CalEvent, onDelete: () -> Unit) {
    val timeText = if (event.allDay) {
        "All day"
    } else {
        Instant.ofEpochMilli(event.start)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("h:mm a"))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = timeText,
            modifier = Modifier.width(76.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.tertiary,
        )
        Text(text = event.title, modifier = Modifier.weight(1f))
        if (event.canEdit) {
            TextButton(onClick = onDelete) { Text("✕") }
        }
    }
}

@Composable
private fun DeleteEventDialog(
    event: CalEvent,
    onDismiss: () -> Unit,
    onDelete: (wholeSeries: Boolean) -> Unit,
) {
    val message = if (event.recurring) {
        "\"${event.title}\" repeats. Deleting it also removes it from Google Calendar and any other calendar app."
    } else {
        "\"${event.title}\" will also be removed from Google Calendar and any other calendar app."
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete from calendar?") },
        text = { Text(message) },
        confirmButton = {
            if (event.recurring) {
                Row {
                    TextButton(onClick = { onDelete(false); onDismiss() }) { Text("Only this day") }
                    TextButton(onClick = { onDelete(true); onDismiss() }) { Text("All repeats") }
                }
            } else {
                TextButton(onClick = { onDelete(true); onDismiss() }) { Text("Delete") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun AddTaskDialog(
    date: LocalDate,
    canSync: Boolean,
    onDismiss: () -> Unit,
    onAdd: (title: String, addToCalendar: Boolean) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var sync by remember { mutableStateOf(canSync) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New task · ${date.format(DateTimeFormatter.ofPattern("d MMM"))}") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    label = { Text("Task") },
                )
                if (canSync) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { sync = !sync },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = sync, onCheckedChange = { sync = it })
                        Text("Also add to my calendar")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    onAdd(title, sync && canSync)
                    onDismiss()
                },
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
