package com.example.caltodo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth

class TodoViewModel(app: Application) : AndroidViewModel(app) {
    private val store = TaskStore(app)
    private val repo = CalendarRepo(app)

    var tasks by mutableStateOf(store.load())
        private set
    var month by mutableStateOf(YearMonth.now())
        private set
    var selected by mutableStateOf(LocalDate.now())
        private set
    var events by mutableStateOf<List<CalEvent>>(emptyList())
        private set
    var calendarConnected by mutableStateOf(repo.hasPermission())
        private set

    init {
        refreshEvents()
    }

    /** Re-checks permission and reloads the calendar events for the visible month. */
    fun refreshEvents() {
        viewModelScope.launch {
            val connected = repo.hasPermission()
            val list = if (connected) {
                withContext(Dispatchers.IO) { repo.eventsForMonth(month) }
            } else {
                emptyList()
            }
            calendarConnected = connected
            events = list
        }
    }

    /** Calendar events minus the ones that are just our own synced tasks (avoids duplicates). */
    fun visibleEvents(): List<CalEvent> {
        val linked = tasks.mapNotNull { it.eventId }.toSet()
        return events.filter { it.id !in linked }
    }

    fun selectDate(date: LocalDate) {
        selected = date
    }

    fun changeMonth(delta: Long) {
        month = month.plusMonths(delta)
        val today = LocalDate.now()
        selected = if (YearMonth.from(today) == month) today else month.atDay(1)
        refreshEvents()
    }

    fun goToday() {
        month = YearMonth.now()
        selected = LocalDate.now()
        refreshEvents()
    }

    fun addTask(title: String, addToCalendar: Boolean) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val date = selected
        viewModelScope.launch {
            val eventId = if (addToCalendar && repo.hasPermission()) {
                withContext(Dispatchers.IO) { repo.addTaskAsEvent(clean, date) }
            } else {
                null
            }
            tasks = tasks + Task(System.currentTimeMillis(), clean, date, false, eventId)
            store.save(tasks)
            if (eventId != null) refreshEvents()
        }
    }

    fun toggle(id: Long) {
        tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
        store.save(tasks)
    }

    fun delete(task: Task) {
        tasks = tasks.filter { it.id != task.id }
        store.save(tasks)
        task.eventId?.let { eventId ->
            viewModelScope.launch {
                withContext(Dispatchers.IO) { repo.deleteEvent(eventId) }
                refreshEvents()
            }
        }
    }
}
